<?php
class Dosen_model extends CI_Model {
    public $id;
    public $nama;
    public $nid;
    public $gender;
    public $matkul;
    public $tmp_lahir;
    public $tgl_lahir;
    
}
