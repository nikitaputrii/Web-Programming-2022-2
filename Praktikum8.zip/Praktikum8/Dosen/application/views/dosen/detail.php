<div class="col-md-12">
    <h3>
    Detail Dosen
    </h3>
    <table class="table">
        <thead>
            <tr>
            <th>id</th><th>NIDN</th><th>Nama</th><th>Gender</th>
            <th>Pendidikan</th><th>Tempat Lahir</th><th>Tanggal Lahir</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <td><?=$dosen->id?></td>
            <td><?=$dosen->nidn?></td>
            <td><?=$dosen->nama?></td>
            <td><?=$dosen->gender?></td>
            <td><?=$dosen->pendidikan?></td>
            <td><?=$dosen->tmp_lahir?></td>
            <td><?=$dosen->tgl_lahir?></td>
            </tr>
        </tbody>
    </table>
</div>